import { useEffect } from 'react'
import { useLocation } from 'react-router'

/**
 * Observes all `.reveal` elements and adds `.is-visible` when they
 * enter the viewport. Re-runs on every route change.
 */
export function useReveal() {
  const { pathname } = useLocation()

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'instant' as ScrollBehavior })

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('is-visible')
            observer.unobserve(entry.target)
          }
        })
      },
      { threshold: 0.12 }
    )

    const attach = () => {
      document
        .querySelectorAll('.reveal:not(.is-visible)')
        .forEach((el) => observer.observe(el))
    }

    // slight delay so newly routed DOM is painted
    const t = setTimeout(attach, 60)
    return () => {
      clearTimeout(t)
      observer.disconnect()
    }
  }, [pathname])
}
