import { useEffect, useState } from 'react'
import { Link, NavLink, useLocation } from 'react-router'
import { Menu, X, ArrowUpRight } from 'lucide-react'

const links = [
  { to: '/', label: 'Home' },
  { to: '/services', label: 'Services' },
  { to: '/about', label: 'About' },
  { to: '/contact', label: 'Contact' },
]

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false)
  const [open, setOpen] = useState(false)
  const { pathname } = useLocation()

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24)
    onScroll()
    window.addEventListener('scroll', onScroll)
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  useEffect(() => setOpen(false), [pathname])

  return (
    <header
      className={`fixed top-0 inset-x-0 z-50 transition-all duration-300 ${
        scrolled
          ? 'bg-zinc-950/85 backdrop-blur-xl border-b border-white/10'
          : 'bg-transparent border-b border-transparent'
      }`}
    >
      <nav className="mx-auto max-w-7xl px-5 sm:px-8 h-16 sm:h-[72px] flex items-center justify-between">
        <Link to="/" className="flex items-center gap-2.5 group">
          <span className="relative grid place-items-center w-9 h-9 rounded-lg bg-gradient-to-br from-emerald-400 to-cyan-500 text-zinc-950 font-black text-sm tracking-tighter glow-emerald">
            G
            <span className="absolute inset-0 rounded-lg ring-1 ring-white/20" />
          </span>
          <span className="text-[15px] font-bold tracking-[0.18em] text-zinc-100 group-hover:text-emerald-300 transition-colors">
            GREY<span className="text-zinc-500">GLOBAL</span>
          </span>
        </Link>

        <div className="hidden md:flex items-center gap-1">
          {links.map((l) => (
            <NavLink
              key={l.to}
              to={l.to}
              className={({ isActive }) =>
                `px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                  isActive
                    ? 'text-emerald-300 bg-emerald-400/10'
                    : 'text-zinc-400 hover:text-zinc-100 hover:bg-white/5'
                }`
              }
            >
              {l.label}
            </NavLink>
          ))}
        </div>

        <div className="hidden md:block">
          <Link
            to="/contact"
            className="inline-flex items-center gap-1.5 rounded-full bg-emerald-400 px-5 py-2.5 text-sm font-semibold text-zinc-950 hover:bg-emerald-300 transition-colors glow-emerald"
          >
            Request Data
            <ArrowUpRight className="w-4 h-4" />
          </Link>
        </div>

        <button
          onClick={() => setOpen(!open)}
          className="md:hidden p-2 text-zinc-300 hover:text-white"
          aria-label="Toggle menu"
        >
          {open ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </nav>

      {open && (
        <div className="md:hidden border-t border-white/10 bg-zinc-950/95 backdrop-blur-xl px-5 py-4 space-y-1">
          {links.map((l) => (
            <NavLink
              key={l.to}
              to={l.to}
              className={({ isActive }) =>
                `block px-4 py-3 rounded-lg text-sm font-medium ${
                  isActive ? 'text-emerald-300 bg-emerald-400/10' : 'text-zinc-300 hover:bg-white/5'
                }`
              }
            >
              {l.label}
            </NavLink>
          ))}
          <Link
            to="/contact"
            className="mt-2 flex items-center justify-center gap-1.5 rounded-full bg-emerald-400 px-5 py-3 text-sm font-semibold text-zinc-950"
          >
            Request Data
            <ArrowUpRight className="w-4 h-4" />
          </Link>
        </div>
      )}
    </header>
  )
}
