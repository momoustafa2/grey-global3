import { Link } from 'react-router'
import { Mail, Globe, MapPin, Linkedin, Twitter } from 'lucide-react'

export default function Footer() {
  return (
    <footer className="border-t border-white/10 bg-zinc-950">
      <div className="mx-auto max-w-7xl px-5 sm:px-8 py-14 grid gap-10 md:grid-cols-4">
        <div className="md:col-span-2 space-y-4">
          <div className="flex items-center gap-2.5">
            <span className="grid place-items-center w-9 h-9 rounded-lg bg-gradient-to-br from-emerald-400 to-cyan-500 text-zinc-950 font-black text-sm">
              G
            </span>
            <span className="text-[15px] font-bold tracking-[0.18em] text-zinc-100">
              GREY<span className="text-zinc-500">GLOBAL</span>
            </span>
          </div>
          <p className="text-sm text-zinc-500 max-w-sm leading-relaxed">
            Premium training data for AI teams — ready-made and custom-collected
            audio, image, and video datasets in every language, built with
            consent-first sourcing and rigorous QA.
          </p>
          <div className="flex gap-3">
            <a
              href="#"
              className="p-2.5 rounded-lg border border-white/10 text-zinc-400 hover:text-emerald-300 hover:border-emerald-400/40 transition-colors"
              aria-label="LinkedIn"
            >
              <Linkedin className="w-4 h-4" />
            </a>
            <a
              href="#"
              className="p-2.5 rounded-lg border border-white/10 text-zinc-400 hover:text-emerald-300 hover:border-emerald-400/40 transition-colors"
              aria-label="Twitter"
            >
              <Twitter className="w-4 h-4" />
            </a>
          </div>
        </div>

        <div>
          <h4 className="text-xs font-semibold uppercase tracking-[0.2em] text-zinc-500 mb-4">
            Company
          </h4>
          <ul className="space-y-2.5 text-sm">
            <li><Link to="/" className="text-zinc-400 hover:text-emerald-300 transition-colors">Home</Link></li>
            <li><Link to="/services" className="text-zinc-400 hover:text-emerald-300 transition-colors">Services</Link></li>
            <li><Link to="/about" className="text-zinc-400 hover:text-emerald-300 transition-colors">About Us</Link></li>
            <li><Link to="/contact" className="text-zinc-400 hover:text-emerald-300 transition-colors">Contact</Link></li>
          </ul>
        </div>

        <div>
          <h4 className="text-xs font-semibold uppercase tracking-[0.2em] text-zinc-500 mb-4">
            Get in Touch
          </h4>
          <ul className="space-y-3 text-sm text-zinc-400">
            <li className="flex items-center gap-2.5">
              <Mail className="w-4 h-4 text-emerald-400" />
              hello@grey-global.com
            </li>
            <li className="flex items-center gap-2.5">
              <Globe className="w-4 h-4 text-emerald-400" />
              100+ languages covered
            </li>
            <li className="flex items-center gap-2.5">
              <MapPin className="w-4 h-4 text-emerald-400" />
              Contributors in 30+ countries
            </li>
          </ul>
        </div>
      </div>

      <div className="border-t border-white/5">
        <div className="mx-auto max-w-7xl px-5 sm:px-8 py-5 flex flex-col sm:flex-row items-center justify-between gap-2 text-xs text-zinc-600">
          <span>© {new Date().getFullYear()} Grey Global. All rights reserved.</span>
          <span>Consent-first data sourcing · GDPR-aligned workflows</span>
        </div>
      </div>
    </footer>
  )
}
