import { useState } from 'react'
import {
  Mail,
  Globe,
  Clock,
  Send,
  CheckCircle2,
  Mic,
  Image as ImageIcon,
  Video,
  Layers,
} from 'lucide-react'

const dataTypeOptions = [
  { value: 'audio', label: 'Audio / Speech', icon: Mic },
  { value: 'image', label: 'Images', icon: ImageIcon },
  { value: 'video', label: 'Video', icon: Video },
  { value: 'mixed', label: 'Mixed / Other', icon: Layers },
]

const inputCls =
  'w-full rounded-xl border border-white/10 bg-zinc-900/60 px-4 py-3 text-sm text-zinc-100 placeholder:text-zinc-600 outline-none focus:border-emerald-400/50 focus:ring-2 focus:ring-emerald-400/20 transition'

export default function Contact() {
  const [dataType, setDataType] = useState('audio')
  const [orderType, setOrderType] = useState<'ready' | 'custom'>('custom')
  const [sent, setSent] = useState(false)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setSent(true)
  }

  return (
    <div className="pt-28 pb-24">
      <section className="relative">
        <div className="absolute inset-0 bg-grid bg-grid-fade" />
        <div className="absolute -top-24 left-1/3 w-[500px] h-[400px] rounded-full bg-emerald-500/10 blur-[130px]" />

        <div className="relative mx-auto max-w-7xl px-5 sm:px-8">
          <div className="max-w-2xl mb-14">
            <span className="reveal text-xs font-semibold uppercase tracking-[0.25em] text-emerald-400">
              Contact
            </span>
            <h1 className="reveal mt-3 text-4xl sm:text-6xl font-extrabold tracking-tight text-zinc-50">
              Tell us what your <span className="text-gradient">model needs</span>
            </h1>
            <p className="reveal mt-5 text-zinc-400 leading-relaxed">
              Share a few details about your project and our data team will get
              back to you with a scoped proposal and timeline.
            </p>
          </div>

          <div className="grid lg:grid-cols-5 gap-10">
            {/* form */}
            <div className="reveal lg:col-span-3 rounded-2xl border border-white/10 bg-zinc-900/50 p-7 sm:p-9">
              {sent ? (
                <div className="py-16 text-center">
                  <CheckCircle2 className="w-14 h-14 text-emerald-400 mx-auto mb-5" />
                  <h2 className="text-2xl font-bold text-zinc-100">Request received</h2>
                  <p className="mt-3 text-sm text-zinc-400 max-w-sm mx-auto leading-relaxed">
                    Thanks for reaching out. Our data team will review your
                    requirements and respond within one business day.
                  </p>
                  <button
                    onClick={() => setSent(false)}
                    className="mt-7 rounded-full border border-white/15 px-6 py-2.5 text-sm font-medium text-zinc-300 hover:border-emerald-400/50 hover:text-emerald-300 transition-colors"
                  >
                    Send another request
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid sm:grid-cols-2 gap-5">
                    <div>
                      <label className="block text-xs font-semibold uppercase tracking-wider text-zinc-500 mb-2">
                        Full Name
                      </label>
                      <input required placeholder="Jane Doe" className={inputCls} />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold uppercase tracking-wider text-zinc-500 mb-2">
                        Work Email
                      </label>
                      <input required type="email" placeholder="jane@company.com" className={inputCls} />
                    </div>
                  </div>

                  <div className="grid sm:grid-cols-2 gap-5">
                    <div>
                      <label className="block text-xs font-semibold uppercase tracking-wider text-zinc-500 mb-2">
                        Company
                      </label>
                      <input placeholder="Your AI company" className={inputCls} />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold uppercase tracking-wider text-zinc-500 mb-2">
                        Languages Needed
                      </label>
                      <input placeholder="e.g. Arabic, English, Swahili" className={inputCls} />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold uppercase tracking-wider text-zinc-500 mb-2">
                      Order Type
                    </label>
                    <div className="grid grid-cols-2 gap-3">
                      {(
                        [
                          { v: 'ready', l: 'Ready-Made Dataset' },
                          { v: 'custom', l: 'Custom Collection' },
                        ] as const
                      ).map((o) => (
                        <button
                          type="button"
                          key={o.v}
                          onClick={() => setOrderType(o.v)}
                          className={`rounded-xl border px-4 py-3 text-sm font-medium transition-colors ${
                            orderType === o.v
                              ? 'border-emerald-400/50 bg-emerald-400/10 text-emerald-300'
                              : 'border-white/10 bg-zinc-900/60 text-zinc-400 hover:border-white/20'
                          }`}
                        >
                          {o.l}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold uppercase tracking-wider text-zinc-500 mb-2">
                      Data Type
                    </label>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                      {dataTypeOptions.map((o) => (
                        <button
                          type="button"
                          key={o.value}
                          onClick={() => setDataType(o.value)}
                          className={`flex flex-col items-center gap-2 rounded-xl border px-3 py-4 text-xs font-medium transition-colors ${
                            dataType === o.value
                              ? 'border-emerald-400/50 bg-emerald-400/10 text-emerald-300'
                              : 'border-white/10 bg-zinc-900/60 text-zinc-400 hover:border-white/20'
                          }`}
                        >
                          <o.icon className="w-5 h-5" />
                          {o.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold uppercase tracking-wider text-zinc-500 mb-2">
                      Project Details
                    </label>
                    <textarea
                      required
                      rows={5}
                      placeholder="Describe your use case, volume needed, target demographics, timeline..."
                      className={`${inputCls} resize-none`}
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full sm:w-auto inline-flex items-center justify-center gap-2 rounded-full bg-emerald-400 px-8 py-3.5 text-sm font-semibold text-zinc-950 hover:bg-emerald-300 transition-colors glow-emerald"
                  >
                    Send Request
                    <Send className="w-4 h-4" />
                  </button>
                </form>
              )}
            </div>

            {/* side info */}
            <div className="lg:col-span-2 space-y-5">
              <div className="reveal card-hover rounded-2xl border border-white/10 bg-zinc-900/50 p-7">
                <Mail className="w-6 h-6 text-emerald-400 mb-4" />
                <h3 className="text-base font-bold text-zinc-100">Email us directly</h3>
                <p className="mt-1.5 text-sm text-zinc-400">hello@grey-global.com</p>
              </div>
              <div className="reveal card-hover rounded-2xl border border-white/10 bg-zinc-900/50 p-7">
                <Clock className="w-6 h-6 text-emerald-400 mb-4" />
                <h3 className="text-base font-bold text-zinc-100">Fast turnaround</h3>
                <p className="mt-1.5 text-sm text-zinc-400 leading-relaxed">
                  We respond within one business day. Ready-made datasets ship
                  the same week; custom orders are scoped within 48 hours.
                </p>
              </div>
              <div className="reveal card-hover rounded-2xl border border-white/10 bg-zinc-900/50 p-7">
                <Globe className="w-6 h-6 text-emerald-400 mb-4" />
                <h3 className="text-base font-bold text-zinc-100">Global by default</h3>
                <p className="mt-1.5 text-sm text-zinc-400 leading-relaxed">
                  Wherever your users are, our contributors are too — 100+
                  languages across 30+ countries.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
