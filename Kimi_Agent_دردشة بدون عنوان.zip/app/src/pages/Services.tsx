import { Link } from 'react-router'
import {
  Mic,
  Image as ImageIcon,
  Video,
  Package,
  SlidersHorizontal,
  Tags,
  ArrowRight,
  CheckCircle2,
  Phone,
  MessageSquare,
  Bell,
  BookOpen,
  Scan,
  Car,
  FileText,
  Users,
  TrafficCone,
  Hand,
  Eye,
  Clapperboard,
} from 'lucide-react'

const catalog = [
  {
    icon: Mic,
    color: 'emerald',
    title: 'Audio & Speech',
    items: [
      { icon: Phone, name: 'Call-Center Conversations', spec: 'Natural agent–customer dialogs, 40+ locales' },
      { icon: MessageSquare, name: 'Spontaneous Speech', spec: 'Unscripted multi-speaker conversations' },
      { icon: Bell, name: 'Wake Words & Commands', spec: 'Far-field & near-field, noisy environments' },
      { icon: BookOpen, name: 'Scripted Dictation', spec: 'Phonetically balanced prompts for TTS' },
    ],
  },
  {
    icon: ImageIcon,
    color: 'cyan',
    title: 'Image',
    items: [
      { icon: Scan, name: 'Object Detection', spec: 'Bounding-boxed scenes, retail & industrial' },
      { icon: FileText, name: 'OCR Documents', spec: 'Receipts, forms, IDs, handwriting samples' },
      { icon: Users, name: 'Consented Human Imagery', spec: 'Diverse demographics, expressions, poses' },
      { icon: Eye, name: 'Scene Understanding', spec: 'Segmented indoor/outdoor environments' },
    ],
  },
  {
    icon: Video,
    color: 'violet',
    title: 'Video',
    items: [
      { icon: TrafficCone, name: 'Traffic & Mobility', spec: 'Dashcam, intersections, pedestrian flows' },
      { icon: Hand, name: 'Gestures & Actions', spec: 'Multi-angle action recognition clips' },
      { icon: Clapperboard, name: 'Scenario Capture', spec: 'Scripted multi-camera events' },
      { icon: Car, name: 'Automotive Perception', spec: 'Day/night, weather, road-condition coverage' },
    ],
  },
]

const colorMap: Record<string, { icon: string; border: string }> = {
  emerald: { icon: 'text-emerald-400', border: 'border-emerald-400/20 bg-emerald-400/10' },
  cyan: { icon: 'text-cyan-300', border: 'border-cyan-400/20 bg-cyan-400/10' },
  violet: { icon: 'text-violet-300', border: 'border-violet-400/20 bg-violet-400/10' },
}

const customFeatures = [
  'Any language, dialect, or regional accent — 100+ covered natively',
  'Any domain: healthcare, legal, finance, automotive, retail, agriculture',
  'Demographic targeting by age, gender, region, and occupation',
  'Your environment, your devices, your recording conditions',
  'Annotation & labeling: transcription, bounding boxes, segmentation, keypoints',
  'Full exclusivity with IP transfer and consent documentation',
]

const comparison = [
  { aspect: 'Delivery time', ready: 'Same week', custom: '2–8 weeks by scope' },
  { aspect: 'Specification', ready: 'Fixed catalog specs', custom: 'Fully tailored to your model' },
  { aspect: 'Languages', ready: 'Top 25 languages', custom: '100+ languages & dialects' },
  { aspect: 'Exclusivity', ready: 'Non-exclusive license', custom: 'Exclusive, IP transfer optional' },
  { aspect: 'Best for', ready: 'Prototyping & benchmarks', custom: 'Production model training' },
]

export default function Services() {
  return (
    <div className="pt-28 pb-8">
      {/* header */}
      <section className="relative">
        <div className="absolute inset-0 bg-grid bg-grid-fade" />
        <div className="absolute -top-24 left-1/3 w-[500px] h-[400px] rounded-full bg-emerald-500/10 blur-[130px]" />
        <div className="relative mx-auto max-w-7xl px-5 sm:px-8 pb-16">
          <span className="reveal text-xs font-semibold uppercase tracking-[0.25em] text-emerald-400">
            Services
          </span>
          <h1 className="reveal mt-3 text-4xl sm:text-6xl font-extrabold tracking-tight text-zinc-50 max-w-3xl">
            Data services built for <span className="text-gradient">AI teams</span>
          </h1>
          <p className="reveal mt-5 text-zinc-400 max-w-2xl leading-relaxed">
            License from our ready-made catalog, or commission a fully custom
            collection — audio, image, and video, in any language on earth.
          </p>
        </div>
      </section>

      {/* ready-made catalog */}
      <section className="py-16">
        <div className="mx-auto max-w-7xl px-5 sm:px-8">
          <div className="reveal flex items-center gap-3 mb-10">
            <div className="w-11 h-11 rounded-xl bg-cyan-400/10 border border-cyan-400/20 grid place-items-center">
              <Package className="w-5 h-5 text-cyan-300" />
            </div>
            <div>
              <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-zinc-50">
                Ready-Made Dataset Catalog
              </h2>
              <p className="text-sm text-zinc-500">Pre-collected, pre-validated, licensed in days</p>
            </div>
          </div>

          <div className="grid lg:grid-cols-3 gap-5">
            {catalog.map((cat) => (
              <div
                key={cat.title}
                className="reveal card-hover rounded-2xl border border-white/10 bg-zinc-900/50 p-7"
              >
                <div className={`w-12 h-12 rounded-xl border grid place-items-center mb-5 ${colorMap[cat.color].border}`}>
                  <cat.icon className={`w-6 h-6 ${colorMap[cat.color].icon}`} />
                </div>
                <h3 className="text-lg font-bold text-zinc-100 mb-5">{cat.title}</h3>
                <ul className="space-y-4">
                  {cat.items.map((item) => (
                    <li key={item.name} className="flex gap-3">
                      <item.icon className="w-4 h-4 mt-1 text-zinc-500 shrink-0" />
                      <div>
                        <div className="text-sm font-semibold text-zinc-200">{item.name}</div>
                        <div className="text-xs text-zinc-500 mt-0.5">{item.spec}</div>
                      </div>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* custom orders */}
      <section className="py-16 border-t border-white/5">
        <div className="mx-auto max-w-7xl px-5 sm:px-8 grid lg:grid-cols-2 gap-12 items-center">
          <div className="reveal">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-11 h-11 rounded-xl bg-emerald-400/10 border border-emerald-400/20 grid place-items-center">
                <SlidersHorizontal className="w-5 h-5 text-emerald-300" />
              </div>
              <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-zinc-50">
                Custom Data Orders
              </h2>
            </div>
            <p className="text-zinc-400 leading-relaxed mb-8">
              Your model is unique — your training data should be too. Send us a
              spec sheet or just a rough idea, and our team designs a collection
              program around it: recruiting contributors, capturing to spec, and
              validating every sample before delivery.
            </p>
            <ul className="space-y-3.5">
              {customFeatures.map((f) => (
                <li key={f} className="flex items-start gap-3 text-sm text-zinc-300">
                  <CheckCircle2 className="w-4 h-4 mt-0.5 text-emerald-400 shrink-0" />
                  {f}
                </li>
              ))}
            </ul>
            <Link
              to="/contact"
              className="mt-9 inline-flex items-center gap-2 rounded-full bg-emerald-400 px-7 py-3.5 text-sm font-semibold text-zinc-950 hover:bg-emerald-300 transition-colors glow-emerald"
            >
              Request a Custom Quote
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>

          {/* comparison table */}
          <div className="reveal rounded-2xl border border-white/10 bg-zinc-900/50 overflow-hidden">
            <div className="grid grid-cols-3 text-xs font-semibold uppercase tracking-wider text-zinc-500 border-b border-white/10">
              <div className="px-5 py-4" />
              <div className="px-5 py-4 text-cyan-300">Ready-Made</div>
              <div className="px-5 py-4 text-emerald-300">Custom</div>
            </div>
            {comparison.map((row, i) => (
              <div
                key={row.aspect}
                className={`grid grid-cols-3 text-sm ${i % 2 === 0 ? 'bg-white/[0.02]' : ''}`}
              >
                <div className="px-5 py-4 text-zinc-400 font-medium">{row.aspect}</div>
                <div className="px-5 py-4 text-zinc-300">{row.ready}</div>
                <div className="px-5 py-4 text-zinc-100">{row.custom}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* annotation strip */}
      <section className="py-16">
        <div className="mx-auto max-w-7xl px-5 sm:px-8">
          <div className="reveal card-hover rounded-2xl border border-white/10 bg-zinc-900/50 p-8 sm:p-10 flex flex-col sm:flex-row items-start sm:items-center gap-6">
            <div className="w-12 h-12 rounded-xl bg-violet-400/10 border border-violet-400/20 grid place-items-center shrink-0">
              <Tags className="w-6 h-6 text-violet-300" />
            </div>
            <div className="flex-1">
              <h3 className="text-xl font-bold text-zinc-100">Annotation & Labeling Add-On</h3>
              <p className="mt-2 text-sm text-zinc-400 leading-relaxed max-w-2xl">
                Every dataset — ready-made or custom — can ship fully annotated:
                transcription with timestamps, bounding boxes, semantic
                segmentation, keypoints, sentiment tags, and more. QA'd twice
                before it reaches you.
              </p>
            </div>
            <Link
              to="/contact"
              className="inline-flex items-center gap-2 rounded-full border border-white/15 px-6 py-3 text-sm font-semibold text-zinc-200 hover:border-emerald-400/50 hover:text-emerald-300 transition-colors shrink-0"
            >
              Ask About Labeling
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </section>
    </div>
  )
}
