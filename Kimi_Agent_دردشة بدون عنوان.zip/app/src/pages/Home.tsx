import { Link } from 'react-router'
import {
  Mic,
  Image as ImageIcon,
  Video,
  ArrowRight,
  ArrowUpRight,
  Database,
  Package,
  SlidersHorizontal,
  Languages,
  ShieldCheck,
  Search,
  ClipboardList,
  Truck,
  CheckCircle2,
} from 'lucide-react'

const stats = [
  { value: '100+', label: 'Languages & dialects' },
  { value: '50M+', label: 'Data assets delivered' },
  { value: '30+', label: 'Countries with contributors' },
  { value: '99%', label: 'QA pass accuracy' },
]

const dataTypes = [
  {
    icon: Mic,
    title: 'Audio & Speech Recordings',
    desc: 'Conversational speech, call-center audio, wake words, dictation, and emotional speech — recorded natively, never scraped.',
    tags: ['ASR', 'TTS', 'Speaker ID', 'Intent'],
  },
  {
    icon: ImageIcon,
    title: 'Image Datasets',
    desc: 'Object detection, OCR documents, scene understanding, and consented human imagery across every demographic.',
    tags: ['Detection', 'OCR', 'Segmentation', 'Faces'],
  },
  {
    icon: Video,
    title: 'Video Datasets',
    desc: 'Action recognition, traffic & mobility, gesture capture, and multi-camera scenarios at any resolution or frame rate.',
    tags: ['Tracking', 'Actions', 'Gestures', '4K'],
  },
]

const languages = [
  'English', 'Arabic', 'Mandarin', 'Spanish', 'Hindi', 'French', 'German',
  'Portuguese', 'Russian', 'Japanese', 'Korean', 'Turkish', 'Swahili',
  'Urdu', 'Bengali', 'Italian', 'Dutch', 'Polish', 'Vietnamese', 'Thai',
  'Indonesian', 'Farsi', 'Ukrainian', 'Amharic', 'Hausa', 'Yoruba',
]

const steps = [
  {
    icon: Search,
    title: 'Scope',
    desc: 'We map your model requirements to a precise data spec — modalities, languages, demographics, volume.',
  },
  {
    icon: ClipboardList,
    title: 'Collect',
    desc: 'Our vetted global contributor network captures data to spec, with consent and licensing built in.',
  },
  {
    icon: ShieldCheck,
    title: 'Validate',
    desc: 'Multi-pass QA: automated checks plus human review until every sample meets the acceptance criteria.',
  },
  {
    icon: Truck,
    title: 'Deliver',
    desc: 'Versioned, documented datasets delivered in your format — ready to train on day one.',
  },
]

export default function Home() {
  return (
    <div className="overflow-x-clip">
      {/* ---------- HERO ---------- */}
      <section className="relative min-h-[92vh] flex items-center pt-24 pb-16">
        <div className="absolute inset-0 bg-grid bg-grid-fade" />
        <div className="absolute -top-32 left-1/2 -translate-x-1/2 w-[700px] h-[700px] rounded-full bg-emerald-500/10 blur-[140px] animate-pulse-slow" />
        <div className="absolute top-1/3 -right-40 w-[420px] h-[420px] rounded-full bg-cyan-500/10 blur-[120px]" />

        <div className="relative mx-auto max-w-7xl px-5 sm:px-8 w-full">
          <div className="max-w-3xl">
            <div className="reveal inline-flex items-center gap-2 rounded-full border border-emerald-400/30 bg-emerald-400/10 px-4 py-1.5 text-xs font-medium text-emerald-300 mb-7">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              AI Training Data · Worldwide Collection Network
            </div>

            <h1 className="reveal text-4xl sm:text-6xl lg:text-7xl font-extrabold leading-[1.05] tracking-tight text-zinc-50">
              Data that makes
              <br />
              <span className="text-gradient">AI smarter.</span>
            </h1>

            <p className="reveal mt-6 text-base sm:text-lg text-zinc-400 leading-relaxed max-w-xl">
              Grey Global collects premium training data for AI companies —
              ready-made datasets and fully custom orders across{' '}
              <span className="text-zinc-200 font-medium">audio recordings, images, and video</span>,
              in every language your model needs.
            </p>

            <div className="reveal mt-9 flex flex-wrap gap-4">
              <Link
                to="/services"
                className="inline-flex items-center gap-2 rounded-full bg-emerald-400 px-7 py-3.5 text-sm font-semibold text-zinc-950 hover:bg-emerald-300 transition-colors glow-emerald"
              >
                Explore Services
                <ArrowRight className="w-4 h-4" />
              </Link>
              <Link
                to="/contact"
                className="inline-flex items-center gap-2 rounded-full border border-white/15 px-7 py-3.5 text-sm font-semibold text-zinc-200 hover:border-emerald-400/50 hover:text-emerald-300 transition-colors"
              >
                Request Custom Data
                <ArrowUpRight className="w-4 h-4" />
              </Link>
            </div>
          </div>

          {/* stats */}
          <div className="reveal mt-16 grid grid-cols-2 lg:grid-cols-4 gap-px rounded-2xl overflow-hidden border border-white/10 bg-white/10">
            {stats.map((s) => (
              <div key={s.label} className="bg-zinc-950/90 backdrop-blur px-6 py-7">
                <div className="text-3xl sm:text-4xl font-extrabold text-gradient">{s.value}</div>
                <div className="mt-1.5 text-xs sm:text-sm text-zinc-500">{s.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ---------- DATA TYPES ---------- */}
      <section className="relative py-24">
        <div className="mx-auto max-w-7xl px-5 sm:px-8">
          <div className="reveal max-w-2xl mb-14">
            <span className="text-xs font-semibold uppercase tracking-[0.25em] text-emerald-400">
              What we collect
            </span>
            <h2 className="mt-3 text-3xl sm:text-5xl font-extrabold tracking-tight text-zinc-50">
              Every modality your model trains on
            </h2>
            <p className="mt-4 text-zinc-400 leading-relaxed">
              From raw capture to annotated, production-ready datasets — sourced
              by real people, in real environments, with full consent.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-5">
            {dataTypes.map((d) => (
              <div
                key={d.title}
                className="reveal card-hover group relative rounded-2xl border border-white/10 bg-zinc-900/50 p-7"
              >
                <div className="w-12 h-12 rounded-xl bg-emerald-400/10 border border-emerald-400/20 grid place-items-center mb-6 group-hover:bg-emerald-400/20 transition-colors">
                  <d.icon className="w-6 h-6 text-emerald-400" />
                </div>
                <h3 className="text-lg font-bold text-zinc-100">{d.title}</h3>
                <p className="mt-3 text-sm text-zinc-400 leading-relaxed">{d.desc}</p>
                <div className="mt-5 flex flex-wrap gap-2">
                  {d.tags.map((t) => (
                    <span
                      key={t}
                      className="rounded-full border border-white/10 bg-white/5 px-3 py-1 text-[11px] font-medium text-zinc-400"
                    >
                      {t}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ---------- READY-MADE VS CUSTOM ---------- */}
      <section className="relative py-24 border-y border-white/5 bg-zinc-900/30">
        <div className="mx-auto max-w-7xl px-5 sm:px-8">
          <div className="reveal text-center max-w-2xl mx-auto mb-14">
            <span className="text-xs font-semibold uppercase tracking-[0.25em] text-emerald-400">
              Two ways to get data
            </span>
            <h2 className="mt-3 text-3xl sm:text-5xl font-extrabold tracking-tight text-zinc-50">
              Off the shelf, or built to order
            </h2>
          </div>

          <div className="grid md:grid-cols-2 gap-5">
            <div className="reveal card-hover rounded-2xl border border-white/10 bg-zinc-950 p-8">
              <div className="flex items-center gap-3 mb-5">
                <div className="w-11 h-11 rounded-xl bg-cyan-400/10 border border-cyan-400/20 grid place-items-center">
                  <Package className="w-5 h-5 text-cyan-300" />
                </div>
                <h3 className="text-xl font-bold text-zinc-100">Ready-Made Datasets</h3>
              </div>
              <p className="text-sm text-zinc-400 leading-relaxed mb-6">
                A growing catalog of pre-collected, pre-validated datasets you can
                license today — ideal for fast prototyping and benchmarking.
              </p>
              <ul className="space-y-3 text-sm text-zinc-300">
                {[
                  'Instant licensing & same-week delivery',
                  'Speech, image, and video across top languages',
                  'Documented specs, splits, and label schemas',
                ].map((f) => (
                  <li key={f} className="flex items-start gap-2.5">
                    <CheckCircle2 className="w-4 h-4 mt-0.5 text-cyan-300 shrink-0" />
                    {f}
                  </li>
                ))}
              </ul>
            </div>

            <div className="reveal card-hover rounded-2xl border border-emerald-400/25 bg-gradient-to-b from-emerald-400/[0.07] to-zinc-950 p-8 relative">
              <span className="absolute top-5 right-5 rounded-full bg-emerald-400/15 border border-emerald-400/30 px-3 py-1 text-[10px] font-semibold uppercase tracking-wider text-emerald-300">
                Most popular
              </span>
              <div className="flex items-center gap-3 mb-5">
                <div className="w-11 h-11 rounded-xl bg-emerald-400/10 border border-emerald-400/25 grid place-items-center">
                  <SlidersHorizontal className="w-5 h-5 text-emerald-300" />
                </div>
                <h3 className="text-xl font-bold text-zinc-100">Custom Data Orders</h3>
              </div>
              <p className="text-sm text-zinc-400 leading-relaxed mb-6">
                Tell us the spec — language, scenario, demographic, volume — and
                our global network collects it from scratch, exclusively for you.
              </p>
              <ul className="space-y-3 text-sm text-zinc-300">
                {[
                  'Any language, dialect, or accent — 100+ covered',
                  'Any domain: medical, legal, automotive, retail & more',
                  'Full exclusivity and IP transfer available',
                ].map((f) => (
                  <li key={f} className="flex items-start gap-2.5">
                    <CheckCircle2 className="w-4 h-4 mt-0.5 text-emerald-300 shrink-0" />
                    {f}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* ---------- LANGUAGE MARQUEE ---------- */}
      <section className="py-20 overflow-hidden">
        <div className="reveal mx-auto max-w-7xl px-5 sm:px-8 mb-10 flex items-end justify-between gap-6">
          <div>
            <span className="text-xs font-semibold uppercase tracking-[0.25em] text-emerald-400">
              Global coverage
            </span>
            <h2 className="mt-3 text-3xl sm:text-4xl font-extrabold tracking-tight text-zinc-50">
              Every language. Every dialect.
            </h2>
          </div>
          <div className="hidden sm:flex items-center gap-2 text-sm text-zinc-500">
            <Languages className="w-4 h-4 text-emerald-400" />
            100+ languages & counting
          </div>
        </div>

        <div className="relative">
          <div className="pointer-events-none absolute inset-y-0 left-0 w-24 bg-gradient-to-r from-zinc-950 to-transparent z-10" />
          <div className="pointer-events-none absolute inset-y-0 right-0 w-24 bg-gradient-to-l from-zinc-950 to-transparent z-10" />
          <div className="flex w-max animate-marquee gap-3">
            {[...languages, ...languages].map((lang, i) => (
              <span
                key={`${lang}-${i}`}
                className="rounded-full border border-white/10 bg-zinc-900/60 px-5 py-2.5 text-sm font-medium text-zinc-300 whitespace-nowrap"
              >
                {lang}
              </span>
            ))}
          </div>
        </div>
      </section>

      {/* ---------- PROCESS ---------- */}
      <section className="py-24 border-t border-white/5">
        <div className="mx-auto max-w-7xl px-5 sm:px-8">
          <div className="reveal max-w-2xl mb-14">
            <span className="text-xs font-semibold uppercase tracking-[0.25em] text-emerald-400">
              How it works
            </span>
            <h2 className="mt-3 text-3xl sm:text-5xl font-extrabold tracking-tight text-zinc-50">
              From spec to dataset in four steps
            </h2>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {steps.map((s, i) => (
              <div
                key={s.title}
                className="reveal card-hover relative rounded-2xl border border-white/10 bg-zinc-900/50 p-7"
              >
                <span className="absolute top-6 right-6 text-4xl font-black text-white/5">
                  0{i + 1}
                </span>
                <div className="w-11 h-11 rounded-xl bg-emerald-400/10 border border-emerald-400/20 grid place-items-center mb-5">
                  <s.icon className="w-5 h-5 text-emerald-400" />
                </div>
                <h3 className="text-base font-bold text-zinc-100">{s.title}</h3>
                <p className="mt-2.5 text-sm text-zinc-400 leading-relaxed">{s.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ---------- CTA ---------- */}
      <section className="py-24">
        <div className="mx-auto max-w-7xl px-5 sm:px-8">
          <div className="reveal relative overflow-hidden rounded-3xl border border-emerald-400/25 bg-gradient-to-br from-emerald-400/10 via-zinc-900 to-zinc-950 px-8 py-16 sm:px-16 text-center">
            <div className="absolute inset-0 bg-grid bg-grid-fade opacity-60" />
            <div className="relative">
              <Database className="w-10 h-10 text-emerald-400 mx-auto mb-6 animate-float" />
              <h2 className="text-3xl sm:text-5xl font-extrabold tracking-tight text-zinc-50">
                Ready to train on better data?
              </h2>
              <p className="mt-4 text-zinc-400 max-w-xl mx-auto leading-relaxed">
                Tell us what your model needs. We'll scope it, collect it, and
                deliver it — in any language, at any scale.
              </p>
              <Link
                to="/contact"
                className="mt-8 inline-flex items-center gap-2 rounded-full bg-emerald-400 px-8 py-4 text-sm font-semibold text-zinc-950 hover:bg-emerald-300 transition-colors glow-emerald"
              >
                Start Your Order
                <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
