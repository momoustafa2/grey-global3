import { Link } from 'react-router'
import {
  Globe2,
  ShieldCheck,
  Users,
  Target,
  Award,
  Scale,
  ArrowRight,
  HeartHandshake,
  Fingerprint,
} from 'lucide-react'

const values = [
  {
    icon: ShieldCheck,
    title: 'Consent First',
    desc: 'Every contributor opts in with clear terms. No scraping, no gray areas — data you can defend in front of any regulator.',
  },
  {
    icon: Globe2,
    title: 'Truly Global',
    desc: 'A vetted contributor network across 30+ countries means native speakers, local contexts, and real-world diversity by default.',
  },
  {
    icon: Award,
    title: 'Quality Obsessed',
    desc: 'Automated validation plus double human review. If a sample misses spec, it never reaches your dataset.',
  },
  {
    icon: Scale,
    title: 'Compliance Ready',
    desc: 'GDPR-aligned workflows, documented licensing, and full audit trails for every asset we deliver.',
  },
]

const milestones = [
  { value: '100+', label: 'Languages collected natively' },
  { value: '30+', label: 'Countries with active contributors' },
  { value: '50M+', label: 'Assets delivered to AI teams' },
  { value: '2×', label: 'Human QA passes on every dataset' },
]

export default function About() {
  return (
    <div className="pt-28 pb-8">
      {/* header */}
      <section className="relative">
        <div className="absolute inset-0 bg-grid bg-grid-fade" />
        <div className="absolute -top-24 right-1/4 w-[500px] h-[400px] rounded-full bg-cyan-500/10 blur-[130px]" />
        <div className="relative mx-auto max-w-7xl px-5 sm:px-8 pb-16">
          <span className="reveal text-xs font-semibold uppercase tracking-[0.25em] text-emerald-400">
            About Grey Global
          </span>
          <h1 className="reveal mt-3 text-4xl sm:text-6xl font-extrabold tracking-tight text-zinc-50 max-w-3xl">
            The data partner behind <span className="text-gradient">better AI</span>
          </h1>
          <p className="reveal mt-5 text-zinc-400 max-w-2xl leading-relaxed">
            AI models are only as good as the data they learn from. We exist to
            give AI companies training data that is diverse, consented, and
            precise — collected by real people, in every language, everywhere.
          </p>
        </div>
      </section>

      {/* mission */}
      <section className="py-16">
        <div className="mx-auto max-w-7xl px-5 sm:px-8 grid lg:grid-cols-2 gap-12 items-center">
          <div className="reveal">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-11 h-11 rounded-xl bg-emerald-400/10 border border-emerald-400/20 grid place-items-center">
                <Target className="w-5 h-5 text-emerald-300" />
              </div>
              <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-zinc-50">
                Our Mission
              </h2>
            </div>
            <p className="text-zinc-400 leading-relaxed mb-5">
              Most AI teams hit the same wall: models stall not because of
              architecture, but because of data. The right voices, the right
              images, the right edge cases — in the right languages — are hard
              to find and harder to collect legally.
            </p>
            <p className="text-zinc-400 leading-relaxed mb-5">
              Grey Global was built to remove that wall. We run a global
              contributor network that captures audio, image, and video data to
              exact specifications — whether that's a ready-made dataset from
              our catalog or a fully custom collection in a language pair
              nobody else covers.
            </p>
            <p className="text-zinc-300 leading-relaxed font-medium">
              Better data in. Better AI out. It's that simple.
            </p>
          </div>

          <div className="reveal grid grid-cols-2 gap-4">
            {milestones.map((m) => (
              <div
                key={m.label}
                className="card-hover rounded-2xl border border-white/10 bg-zinc-900/50 p-7 text-center"
              >
                <div className="text-3xl sm:text-4xl font-extrabold text-gradient">{m.value}</div>
                <div className="mt-2 text-xs sm:text-sm text-zinc-500">{m.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* values */}
      <section className="py-16 border-t border-white/5">
        <div className="mx-auto max-w-7xl px-5 sm:px-8">
          <div className="reveal max-w-2xl mb-12">
            <span className="text-xs font-semibold uppercase tracking-[0.25em] text-emerald-400">
              What we stand for
            </span>
            <h2 className="mt-3 text-3xl sm:text-4xl font-extrabold tracking-tight text-zinc-50">
              Principles we never compromise
            </h2>
          </div>

          <div className="grid sm:grid-cols-2 gap-5">
            {values.map((v) => (
              <div
                key={v.title}
                className="reveal card-hover rounded-2xl border border-white/10 bg-zinc-900/50 p-8"
              >
                <div className="w-12 h-12 rounded-xl bg-emerald-400/10 border border-emerald-400/20 grid place-items-center mb-5">
                  <v.icon className="w-6 h-6 text-emerald-400" />
                </div>
                <h3 className="text-lg font-bold text-zinc-100">{v.title}</h3>
                <p className="mt-2.5 text-sm text-zinc-400 leading-relaxed">{v.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* network strip */}
      <section className="py-16">
        <div className="mx-auto max-w-7xl px-5 sm:px-8">
          <div className="reveal relative overflow-hidden rounded-3xl border border-white/10 bg-gradient-to-br from-zinc-900 to-zinc-950 px-8 py-14 sm:px-14">
            <div className="absolute inset-0 bg-grid bg-grid-fade opacity-50" />
            <div className="relative grid lg:grid-cols-3 gap-10">
              <div className="lg:col-span-2">
                <div className="flex items-center gap-3 mb-5">
                  <Users className="w-6 h-6 text-emerald-400" />
                  <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-zinc-50">
                    A contributor network like no other
                  </h2>
                </div>
                <p className="text-zinc-400 leading-relaxed max-w-xl">
                  Thousands of vetted contributors across 30+ countries — native
                  speakers, domain experts, and field collectors — ready to
                  capture data in the languages, accents, and environments your
                  model actually needs. Fair pay, clear consent, real diversity.
                </p>
                <div className="mt-7 flex flex-wrap gap-3">
                  {['Native speakers', 'Domain experts', 'Field collectors', 'QA reviewers'].map((t) => (
                    <span
                      key={t}
                      className="rounded-full border border-emerald-400/25 bg-emerald-400/10 px-4 py-1.5 text-xs font-medium text-emerald-300"
                    >
                      {t}
                    </span>
                  ))}
                </div>
              </div>
              <div className="flex flex-col justify-center gap-4">
                <div className="flex items-center gap-3 rounded-xl border border-white/10 bg-zinc-950/70 p-4">
                  <Fingerprint className="w-5 h-5 text-emerald-400 shrink-0" />
                  <span className="text-sm text-zinc-300">Identity-verified contributors</span>
                </div>
                <div className="flex items-center gap-3 rounded-xl border border-white/10 bg-zinc-950/70 p-4">
                  <HeartHandshake className="w-5 h-5 text-emerald-400 shrink-0" />
                  <span className="text-sm text-zinc-300">Fair compensation, always</span>
                </div>
                <div className="flex items-center gap-3 rounded-xl border border-white/10 bg-zinc-950/70 p-4">
                  <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0" />
                  <span className="text-sm text-zinc-300">Signed consent on every asset</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16">
        <div className="mx-auto max-w-7xl px-5 sm:px-8 text-center">
          <h2 className="reveal text-3xl sm:text-4xl font-extrabold tracking-tight text-zinc-50">
            Let's build your dataset
          </h2>
          <p className="reveal mt-4 text-zinc-400 max-w-lg mx-auto">
            Ready-made or custom — tell us what your model needs and we'll make
            it happen.
          </p>
          <Link
            to="/contact"
            className="reveal mt-8 inline-flex items-center gap-2 rounded-full bg-emerald-400 px-8 py-4 text-sm font-semibold text-zinc-950 hover:bg-emerald-300 transition-colors glow-emerald"
          >
            Get in Touch
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
      </section>
    </div>
  )
}
